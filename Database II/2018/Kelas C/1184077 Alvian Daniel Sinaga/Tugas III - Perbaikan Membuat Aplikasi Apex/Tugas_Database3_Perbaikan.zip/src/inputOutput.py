npm = input("Masukkan NPM anda: ")

print(npm)