
#if kondisi
if umur < 16:
    #if kondisi
    if umur > 8:
        #Perintah
        print("6 tahun lagi masuk")