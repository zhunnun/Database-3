try:
	string  = "1"
	integer = 3

	hasil = string + integer
except:
	print("Kondisi diatas Tidak dapat dioprasikan dengan benar Laeee....")