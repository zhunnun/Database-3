nama = "alvian"
if nama != "":
	print("yap tepat ada nama")
	if nama == "alvian":
		print("anak kelas D4 TI 2C")
	else:
		print("Bukan Anak kelas D4 TI 2C")
else:
	print("jadi anda siapa?")