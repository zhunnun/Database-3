y = 0
while y < 6:
    print("Alvian sangat Wkwkw")
    y+=1