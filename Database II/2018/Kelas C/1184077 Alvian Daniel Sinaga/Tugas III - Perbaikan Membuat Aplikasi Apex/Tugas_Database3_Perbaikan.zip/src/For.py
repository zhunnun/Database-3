for y in range(7):
    print("Alvian Baik wkwkw")