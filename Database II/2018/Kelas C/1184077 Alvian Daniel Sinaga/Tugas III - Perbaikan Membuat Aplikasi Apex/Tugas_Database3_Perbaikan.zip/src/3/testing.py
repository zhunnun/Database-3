#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 05:59:23 2019

@author: awangga
"""
#fungsinya di definisikan
def Penambahan(a,b):
	r = a + b
	return r

#cara manggil fungsi	
a=2
b=13

anu=Penambahan(a,b)