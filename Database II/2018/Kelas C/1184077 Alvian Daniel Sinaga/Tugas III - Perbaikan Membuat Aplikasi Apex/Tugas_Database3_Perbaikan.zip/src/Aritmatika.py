varchar = "10"
tambah = int(varchar) + 1
print(tambah)
kurang = 3 - 2
print(kurang)
kali = 3 * 2
print(kali)
bagi = 2 / 1
print(bagi)
strbagi = str(bagi)
print(strbagi)
