npm=int(input("masukan NPM anda : "))
TwoLastDigit=abs(npm)%100
for i in range(TwoLastDigit):
    print("Halo, ", npm, " apa kabar ?")
    
