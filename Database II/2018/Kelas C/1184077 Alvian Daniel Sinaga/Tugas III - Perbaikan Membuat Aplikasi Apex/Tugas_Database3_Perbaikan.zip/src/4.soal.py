npm=int(input("Masukan NPM : "))
key=npm%1000
str_key=str(key)
print("Halo, "+str_key[0]+" apa kabar ?")
